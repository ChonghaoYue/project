# Lucene-based dictionary look-up system
  Lucene-based sieve normalization system.
  
## Getting Started
 
### Data format
 * To-do: add all required data repo and their format
 
 ### Code to run
 * To-do: add main class and pipelines